# Blog posts

## Description
* A design of 3 blog posts using html and Vanilla framework.
* Data is obtained from the designated API and injected into the html via a script.

## Technologies
* HTML
* JavaScript
* Vanilla framework

### Run this project
* Clone the repository.
* Open the file index.html in any browser.